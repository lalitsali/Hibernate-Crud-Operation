package com.Hibernate_Maven.controller;
import java.util.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.Hibernate_Maven.entity.Employee;

public class EmployeeMain {
	
	//insert
     public static void insert() {
    	 Configuration con=new Configuration();
    	 con.configure("Hibernate.cfg.xml");
    	 SessionFactory factory =con.buildSessionFactory();
    	 Session session=factory.openSession();
    	 Transaction transaction=session.beginTransaction();
    	 
    	 Employee e1=new Employee(104,"Raj","sali",7877,12);

    	// session.save(e);
    	 session.save(e1);

    	 transaction.commit();
    	 session.close();
    	 factory.close();
    	 
     }
     //delete
     
     public static void delete() {
    	 Configuration con=new Configuration();
    	 con.configure("Hibernate.cfg.xml");
    	 SessionFactory factory =con.buildSessionFactory();
    	 Session session=factory.openSession();
    	 Transaction transaction=session.beginTransaction();
    	 
    	 Employee e1= session.get(Employee.class,11);
    	 session.delete(e1);//object
    	 transaction.commit();
 		session.close();
 		factory.close();

    	 
     }
     
     //update
     public static void update() {
    	 Configuration con=new Configuration();
    	 con.configure("Hibernate.cfg.xml");
    	 SessionFactory factory =con.buildSessionFactory();
    	 Session session=factory.openSession();
    	 Transaction transaction=session.beginTransaction();
    	 
    	 Employee e1=new Employee();
    	 e1.setEmpid(8);
    	 e1.setFname("Lalit");
    	 e1.setLname("sali");
    	 e1.setSalary(5654);
    	 e1.setContact(542848);

    	 session.update(e1);//object
    	 transaction.commit();
 		 session.close();
 		 factory.close();
     }
     
     
   //read
 	public static void read() {
 		Configuration con=new Configuration();
   	 con.configure("Hibernate.cfg.xml");
   	 SessionFactory factory =con.buildSessionFactory();
   	 Session session=factory.openSession();
   	 Transaction transaction=session.beginTransaction();
 		
 		
 		 int empid = 5;  
 		Employee e = session.get(Employee.class, empid);
 	        
 		if (e != null) {
 	            System.out.println("employee ID: " + e.getEmpid()+ ", Fname: " + e.getFname()+",Salary: "+e.getSalary()+",contact: "+e.getContact());
 	        } else {
 	            System.out.println("No patient found with ID: " + empid);
 	        }
 	        
 		transaction.commit();
 		session.close();
 		factory.close();
 	}
     
     
 	 public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
         int choice;
         do {
             System.out.println("Choose an operation:");
             System.out.println("1. Insert");
             System.out.println("2. Delete");
             System.out.println("3. Update");
             System.out.println("4. Read");
             System.out.println("5. Exit");
             choice = scanner.nextInt();

             switch (choice) {
                 case 1:
                     insert();
                     break;
                 case 2:
                     delete();
                     break;
                 case 3:
                     update();
                     break;
                 case 4:
                     read();
                     break;
                 case 5:
                     System.out.println("Exiting...");
                     break;
                 default:
                     System.out.println("Invalid choice. Please try again.");
                     break;
             }
         } while (choice != 5);
         scanner.close();
     }
}
